Rogueliki.onLoad({
  type: 'Rogueliki.Item.Scroll.Wiki',

  wiki: '42'
});
