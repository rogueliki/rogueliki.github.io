#!/usr/local/bin/perl -w

use strict;

use File::Find;

my $file = 'list.txt';

if (open my $fh, '>', $file) {
  find(sub { m/.js$/ and print $fh $File::Find::name, "\n" }, 'lib');
  close $fh;
}

