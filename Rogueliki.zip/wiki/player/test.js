Rogueliki.onLoad({
  type: 'Rogueliki.Player',

  items: ['?']
});
