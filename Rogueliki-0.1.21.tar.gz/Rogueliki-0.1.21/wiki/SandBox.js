Rogueliki.onLoad(
({date:"Tue May 15 2007 14:48:35 GMT+0900"})
);
