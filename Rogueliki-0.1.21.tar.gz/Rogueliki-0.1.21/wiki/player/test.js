Rogueliki.onLoad({
  type: 'Rogueliki.Player',

  items: {
    'a' : 'Rogueliki.Item.Clipboard',
    'b' : '?',
    'c' : 'Rogueliki.Item.PencilCase',
    length: 3
  }
});
