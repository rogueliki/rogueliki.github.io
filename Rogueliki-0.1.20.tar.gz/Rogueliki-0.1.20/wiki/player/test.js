Rogueliki.onLoad({
  type: 'Rogueliki.Player',

  items: {
    't' : '?',
    length: 1
  }
});
