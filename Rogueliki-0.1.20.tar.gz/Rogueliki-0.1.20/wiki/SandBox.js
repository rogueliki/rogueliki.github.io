Rogueliki.onLoad(
{
"date": "Sun May 13 11:15:54 UTC+0900 2007"
}
);
