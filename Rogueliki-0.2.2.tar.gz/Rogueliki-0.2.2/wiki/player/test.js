Rogueliki.onLoad({
  type: 'Rogueliki.Player',

  items: {
    'a' : 'Rogueliki.Item.Clipboard',
    'b' : 'item:test',
    'c' : 'Rogueliki.Item.PencilCase',
    'd' : '?',
    'e' : '?'
  }
});
