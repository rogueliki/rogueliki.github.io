Rogueliki.onLoad({
  type: 'Rogueliki.Player.Human',

  items: {}
});
