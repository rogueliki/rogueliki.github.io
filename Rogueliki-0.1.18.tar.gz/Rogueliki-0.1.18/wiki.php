<?php

require_once('XML/RPC.php');
require_once('XML/RPC/Server.php');

$_GLOBALS['XML_RPC_defencoding'] = 'UTF-8';
$dir = 'wiki';
$plain = $_GET['plain'];

function str2file($str) {
  return preg_replace_callback(
    '/[^\w-_.!~\'()]/',
    create_function(
      '$word',
      'return \'%\' . strtoupper(implode(\'\', unpack(\'H2\', $word[0])));'
    ),
    $str
  );
}

function get_all_pages($params) {
  global $dir, $plain;
  $list = array();

  $fp = fopen($dir . '/RecentChanges.txt', 'r');
  flock($fp, LOCK_SH);
  while (!feof($fp)) {
    $line = substr(rtrim(fgets($fp)), 20) // strip date section
      and array_push($list, str_replace(array('[[', ']]'), '', $line));
  }
  fclose($fp);

  return $plain
    ? implode("\n", $list)
    : new XML_RPC_Response(XML_RPC_encode($list));
}

function get_page($params) {
  global $dir, $plain;
  $log = '';
  $page = $params->getParam(0);

  if ($fp = fopen($dir . '/' . str2file($page->scalarval()) . '.txt', 'r')) {
    flock($fp, LOCK_SH);
    while (!feof($fp)) {
      $log .= fgets($fp);
    }
    fclose($fp);
  }

  return $plain
    ? $log
    : new XML_RPC_Response(XML_RPC_encode($log));
}

function put_page($params) {
  global $dir, $plain;
  $page = $params->getParam(0);
  $content = $params->getParam(1);
  $reserved = array('RecentChanges');
  $result = 0;

  if (array_search($page->scalarval(), $reserved) === FALSE
      and $fp = fopen($dir . '/' . str2file($page->scalarval()) . '.txt', 'w')) {
    flock($fp, LOCK_EX);
    fwrite($fp, preg_replace("/\r?\n/", "\n", $content->scalarval()));
    fclose($fp);

    update_changes($page->scalarval());

    $result = 1;
  }

  return $plain
    ? $result
    : new XML_RPC_Response(new XML_RPC_Value($result, 'boolean'));
}

function update_changes($str) {
  global $dir;
  $log = date('Y-m-d H:i:s ') . '[[' . $str . "]]\n";

  if ($fp = fopen($dir . '/RecentChanges.txt', 'r+')) {
    flock($fp, LOCK_EX);
    while (!feof($fp)) {
      $line = fgets($fp);
      str_replace(array('[[', ']]'), '', substr(rtrim($line), 20)) != $str
        and $log .= $line;
    }
    fseek($fp, 0, SEEK_SET);
    fwrite($fp, $log);
    ftruncate($fp, ftell($fp));
    fclose($fp);
  }
}

if (!$_GET['html']) {
  error_reporting(E_ERROR & E_PARSE); // suppress Warning XML/RPC/Server.php header
  header('Content-Type: text/xml; charset=UTF-8'); // dou jou
  $s = new XML_RPC_Server(array(
    'wiki.getAllPages' => array('function' => 'get_all_pages'),
    'wiki.getPage' => array('function' => 'get_page'),
    'wiki.putPage' => array('function' => 'put_page')
  ));
} else {
?>
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ja" lang="ja">

<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <meta http-equiv="content-style-type" content="text/css" />
  <meta http-equiv="content-script-type" content="text/javascript" />
  <title>wiki</title>
  <link rel="stylesheet" href="default.css" type="text/css" media="screen, print" />
  <script type="text/javascript" src="lib/JSAN.js"></script>
  <script type="text/javascript" src="lib/XMLRPC/Minimal.js"></script>
  <script type="text/javascript" src="lib/WikiRPC.js"></script>
</head>

<body>

<form id="fm" name="fm">
  <textarea name="ta" id="ta" cols="80" rows="20">
var wiki = new WikiRPC('wiki.php');
alert('getPage:\n' + wiki.getPage('SandBox'));
alert(
  wiki.putPage('SandBox', new Date().toString())
    ? 'putPage: Succeeded'
    : 'putPage: Failed'
);
alert('getPage:\n' + wiki.getPage('SandBox'));
</textarea>
  <input name="cb" id="cb" type="checkbox" />
  <label for="cb">alert</label>
  <input type="button" onclick="document.fm.cb.checked ? alert(eval(document.fm.ta.value)) : eval(document.fm.ta.value)" value="eval" />
</form>

<script type="text/javascript">

</script>

</body>

</html>
<?php
}
?>